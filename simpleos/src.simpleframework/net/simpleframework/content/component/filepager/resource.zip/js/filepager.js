
function __filepager_addMethods(action, idParameterName) {
	var _params = function(o, params) {
		return (idParameterName + "=" + action.rowId(o)).addParameter(params);
	};
	
	action.add = function(params) {
		var aa = $Actions["ajaxAddFilePage"];
		aa.selector = action.selector;
		$Actions["addFilepagerWindow"](params);
	};

	action.edit = function(o, params) {
		var ea = $Actions["ajaxEditFilePage"];
		ea.selector = action.selector;
		$Actions["editFilepagerWindow"](_params(o, params));
	};
	
	action.del = function(o, params) {
		var da = $Actions["filePagerDelete"];
		da.selector = action.selector;
		da(_params(o, params));
	};
	
	action.del2 = function(params) {
		action.__checkall(function(ids) {
			var da = $Actions["filePagerDelete"];
			da.selector = action.selector;
			da((idParameterName + "=" + ids).addParameter(params));
		});
	};

	action.download = function(fileId) {
		var da = $Actions["ajaxFilepagerDownload"];
		da.selector = action.selector;
		$Actions["filepagerDownloadWindow"](idParameterName + "=" + fileId);
	};

	action.top = function(o, params) {
		var ta = $Actions["ajaxFilepagerTop"];
		ta.selector = action.selector;
		ta(_params(o, params));
	};
}