function __catalog_addMethods(pa, idParameterName, beanId) {
	var _params = function(o, params) {
		return (idParameterName + "=" + pa.__branch(o).getId())
				.addParameter(params);
	};

	pa.add = function(o, params) {
		var ea = $Actions["ajaxAddCatalogPage"];
		ea.selector = pa.selector;
		var branch = pa.__branch(o);
		if (branch)
			params = ("parentId=" + branch.getId()).addParameter(params);
		var win = $Actions["catalogWindow"];
		win.contentRef = "ajaxAddCatalogPage";
		win(params);
	};

	pa.edit = function(o, params) {
		var ea = $Actions["ajaxEditCatalogPage"];
		ea.selector = pa.selector;
		var win = $Actions["catalogWindow"];
		win.contentRef = "ajaxEditCatalogPage";
		win(_params(o, params));
	};

	pa.del = function(o, params) {
		var ea = $Actions["ajaxCatalogDelete"];
		ea.selector = pa.selector;
		ea(_params(o, params));
	};

	pa.move = function(o, up) {
		var p = __tree_move(pa.__branch(o), up);
		if (p) {
			var ma = $Actions["ajaxCatalogMove"];
			ma.selector = pa.selector;
			ma(p);
		}
	};

	pa.move2 = function(o, up) {
		var p = __tree_move2(pa.__branch(o), up);
		if (p) {
			var ma = $Actions["ajaxCatalogMove"];
			ma.selector = pa.selector;
			ma(p);
		}
	};

	pa.owner_mgr = function(o, params) {
		var oa = $Actions["ajaxCatalogOwnerPage"];
		oa.selector = pa.selector;
		$Actions["catalogOwnerWindow"](_params(o, params));
	};

	pa.refresh = function(params) {
		var ta = $Actions["__catalogTree_" + beanId];
		ta.selector = pa.selector;
		ta.refresh(params);
	};

	pa.expand = function(o) {
		pa.__branch(o).expand();
	};

	pa.collapse = function(o) {
		pa.__branch(o).collapse();
	};

	pa.__branch = function(o) {
		if (!o)
			return;
		o = $target(o);
		return o.branch || o.up(".tafelTreecanevas").down().branch;
	};
};