var picShow = {
	ps : function(objName) {
		if (document.getElementById) {
			return eval('document.getElementById("' + objName + '")')
		} else {
			return eval("document.all." + objName)
		}
	},
	isIE : navigator.appVersion.indexOf("MSIE") != -1 ? true : false,
	addEvent : function(c, a, b) {
		if (c.attachEvent) {
			c.attachEvent("on" + a, b)
		} else {
			c.addEventListener(a, b, false)
		}
	},
	delEvent : function(c, a, b) {
		if (c.detachEvent) {
			c.detachEvent("on" + a, b)
		} else {
			c.removeEventListener(a, b, false)
		}
	},
	readCookie : function(b) {
		var d = "", c = b + "=";
		if (document.cookie.length > 0) {
			var e = document.cookie.indexOf(c);
			if (e != -1) {
				e += c.length;
				var a = document.cookie.indexOf(";", e);
				if (a == -1) {
					a = document.cookie.length
				}
				d = document.cookie.substring(e, a)
			}
		}
		return d
	},
	writeCookie : function(e, f, a, b) {
		var d = "", g = "";
		if (a != null) {
			d = new Date((new Date).getTime() + a * 3600000);
			d = "; expires=" + d.toGMTString()
		}
		if (b != null) {
			g = ";domain=" + b
		}
		document.cookie = e + "=" + escape(f) + d + g
	},
	readStyle : function(c, b) {
		if (c.style[b]) {
			return c.style[b]
		} else {
			if (c.currentStyle) {
				return c.currentStyle[b]
			} else {
				if (document.defaultView
						&& document.defaultView.getComputedStyle) {
					var a = document.defaultView.getComputedStyle(c, null);
					return a.getPropertyValue(b)
				} else {
					return null
				}
			}
		}
	},
	absPosition : function(g, b) {
		var f = 0;
		var d = 0;
		var a = g;
		try {
			do {
				f += a.offsetLeft;
				d += a.offsetTop;
				a = a.offsetParent
			} while (a.id != document.body && a.id != document.documentElement
					&& a != b && a != null)
		} catch (c) {
		}
		return {
			left : f,
			top : d
		}
	},
	style : {
		setOpacity : function(b, a) {
			if (typeof (b.style.opacity) != "undefined") {
				b.style.opacity = a
			} else {
				b.style.filter = "Alpha(Opacity=" + (a * 100) + ")"
			}
		}
	},
	extend : {
		show : function(c, d) {
			if (picShow.readStyle(c, "display") === "none") {
				c.style.display = "block"
			}
			picShow.style.setOpacity(c, 0);
			if (!d) {
				d = 200
			}
			var a = 0, b = d / 20;
			clearTimeout(c._extend_show_timeOut);
			c._extend_show_timeOut = setTimeout(function() {
				if (a >= 1) {
					return

					

										

					

															

					

										

					

																				

					

										

					

															

					

										

					

				}
				a += 1 / b;
				picShow.style.setOpacity(c, a);
				c._extend_show_timeOut = setTimeout(arguments.callee, 20)
			}, 20)
		},
		hide : function(c, d) {
			if (!d) {
				d = 200
			}
			picShow.style.setOpacity(c, 1);
			var a = 1, b = d / 20;
			clearTimeout(c._extend_show_timeOut);
			c._extend_show_timeOut = setTimeout(function() {
				if (a <= 0) {
					c.style.display = "none";
					picShow.style.setOpacity(c, 1);
					return

					

										

					

															

					

										

					

																				

					

										

					

															

					

										

					

				}
				a -= 1 / b;
				picShow.style.setOpacity(c, a);
				c._extend_show_timeOut = setTimeout(arguments.callee, 20)
			}, 20)
		},
		actPX : function(g, h, a, f, e, b, i) {
			if (typeof (i) == "undefined") {
				i = "px"
			}
			clearTimeout(g["_extend_actPX" + h.replace(/\-\.\=/, "_")
					+ "_timeOut"]);
			if (a > f) {
				e = -Math.abs(e)
			} else {
				e = Math.abs(e)
			}
			var c = a;
			var d = f - a;
			g["_extend_actPX" + h.replace(/\-\.\=/, "_") + "_timeOut"] = setTimeout(
					function() {
						c += e;
						var j = f - c;
						if (a < f) {
							if (j < d / 3) {
								e = Math.ceil(j / 3)
							}
							if (j <= 0) {
								g[h] = f + i;
								if (b) {
									b()
								}
								return

								

																

								

																								

								

																

								

																																

								

																

								

																								

								

																

								

							}
						} else {
							if (j > d / 3) {
								e = Math.floor(j / 3)
							}
							if (j >= 0) {
								g[h] = f + i;
								if (b) {
									b()
								}
								return

								

																

								

																								

								

																

								

																																

								

																

								

																								

								

																

								

							}
						}
						g[h] = c + i;
						g["_extend_actPX" + h.replace(/\-\.\=/, "_")
								+ "_timeOut"] = setTimeout(arguments.callee, 20)
					}, 20)
		}
	}
};
picShow.Step = function() {
	this.stepIndex = 0;
	this.classBase = "step_";
	this.limit = 3;
	this.stepTime = 20;
	this.element = null;
	this._timeObj = null;
	this._type = "+"
};
picShow.Step.prototype.action = function(b) {
	if (!this.element) {
		return

		

				

		

						

		

				

		

								

		

				

		

						

		

				

		

	}
	var a = this;
	if (b == "+") {
		this._type = "+"
	} else {
		this._type = "-"
	}
	clearInterval(this._timeObj);
	this._timeObj = setInterval(function() {
		a.nextStep()
	}, this.stepTime)
};
picShow.Step.prototype.nextStep = function() {
	if (this._type == "+") {
		this.stepIndex++
	} else {
		this.stepIndex--
	}
	if (this.stepIndex <= 0) {
		clearInterval(this._timeObj);
		this.stepIndex = 0;
		if (this._type == "-") {
			if (this.onfirst) {
				this.onfirst()
			}
		}
	}
	if (this.stepIndex >= this.limit) {
		clearInterval(this._timeObj);
		this.stepIndex = this.limit;
		if (this._type == "+") {
			if (this.onlast) {
				this.onlast()
			}
		}
	}
	this.element.className = this.classBase + this.stepIndex;
	if (this.onstep) {
		this.onstep()
	}
};
var getData = {
	initF : false,
	nextUrl : "",
	preUrl : "",
	curUrl : "",
	fillData : function(m) {
		epidiascope.clearData();
		var d = slide_data.images;
		var a = slide_data.slide;
		var e = "";
		if (a.path) {
			e = a.path
		}
		var h = "", g = "";
		for ( var n = 0; n < d.length; n++) {
			var s, f, b, p, k, c, r, callback;
			f = e + "/" + d[n].image_url;
			b = d[n].createtime;
			s = d[n].title;
			p = d[n].intro;
			if (e != "")
				k = e + "/" + d[n].thumb_160;
			else
				k = d[n].thumb_160;
			if (e != "")
				c = e + "/" + d[n].thumb_50;
			else
				c = d[n].thumb_50;
			r = d[n].id;
			callback = d[n].callback;
			epidiascope.add({
				src : f,
				date : b,
				title : s,
				text : p,
				lowsrc_b : k,
				lowsrc_s : c,
				id : r,
				callback : callback
			});
			if (h != "") {
				h += "|"
			}
			h += f;
			if (g != "") {
				g += "|"
			}
			if (!getData.initF) {
				g += encodeURIComponent(s) + "#����"
						+ encodeURIComponent(p.replace(/<.*?>/g, ""))
			} else {
				g += s + "#����" + p.replace(/<.*?>/g, "")
			}
		}
		var l = picShow.ps("efpPrePic");
		var j = picShow.ps("efpPreTxt");
		var q = picShow.ps("efpNextPic");
		var o = picShow.ps("efpNextTxt");
		l.getElementsByTagName("a")[0].title = slide_data.prev_album.arg;
		l.getElementsByTagName("a")[0].href = "";
		l.getElementsByTagName("img")[0].src = e
				+ slide_data.prev_album.thumb_50;
		l.getElementsByTagName("img")[0].alt = slide_data.prev_album.title;
		l.getElementsByTagName("img")[0].title = slide_data.prev_album.title;
		j.getElementsByTagName("a")[0].href = "";
		j.getElementsByTagName("a")[0].title = slide_data.prev_album.arg;
		q.getElementsByTagName("a")[0].title = slide_data.next_album.arg;
		q.getElementsByTagName("a")[0].href = "";
		q.getElementsByTagName("img")[0].src = e
				+ slide_data.next_album.thumb_50;
		q.getElementsByTagName("img")[0].alt = slide_data.next_album.title;
		q.getElementsByTagName("img")[0].title = slide_data.next_album.title;
		o.getElementsByTagName("a")[0].title = slide_data.next_album.arg;
		o.getElementsByTagName("a")[0].href = "";
		if (!getData.initF) {
			epidiascope.init();
			getData.initF = true
		} else {
			epidiascope.initNot();
			if (m) {
				epidiascope.select(d.length - 1)
			} else {
				epidiascope.select(0)
			}
		}
	}
};
var epidiascope = {
	picTitleId : "d_picTit",
	picMemoId : "d_picIntro",
	picListId : "efpPicListCont",
	BigPicId : "d_BigPic",
	picArrLeftId : "efpLeftArea",
	picArrRightId : "efpRightArea",
	playButtonId : "ecbPlay",
	statusId : "ecpPlayStatus",
	mainBoxId : "efpBigPic",
	repetition : false,
	prefetch : false,
	autoPlay : false,
	mode : "player",
	autoPlayTimeObj : null,
	timeSpeed : 5,
	maxWidth : 948,
	filmstrips : [],
	prefetchImg : [],
	selectedIndex : -1,
	previousPicList : {},
	nextPicList : {},
	loadTime : 0,
	add : function(a) {
		this.filmstrips.push(a);
		if (this.prefetch) {
			var b = new Image();
			b.src = a.src;
			this.prefetchImg.push(b)
		}
	},
	clearData : function() {
		this.selectedIndex = -1;
		this.filmstrips = []
	},
	jsClickCallBack : function(index) {
		this.select(index);
		if (this.filmstrips[index].callback)
			this.filmstrips[index].callback(this.filmstrips[index]);
	},
	init : function() {
		var e = this;
		var f = 0;
		if (this.filmstrips.length * 110 < picShow.ps(this.picListId).offsetWidth) {
			f = Math.round(picShow.ps(this.picListId).offsetWidth / 2
					- this.filmstrips.length * 110 / 2)
		}
		var d = '<div style="width:32760px;padding-left:' + f + 'px;">', g;
		for (g = 0; g < this.filmstrips.length; g++) {
			if (this.filmstrips[g].title != '') {
				d += '<div class="pic" style="padding:1px 0px;" id="slide_'
						+ g
						+ '"><table cellspacing="0" width="100%"><tr><td class="picCont"><table cellspacing="0"><tr><td class="pb_01"></td><td class="pb_02"></td><td class="pb_03"></td></tr><tr><td class="pb_04"></td><td>'
						+ '<a href="javascript:epidiascope.jsClickCallBack('
						+ g
						+ ');" onclick="this.blur();"><img style="width: 70px;height: 70px;" src="'
						+ this.filmstrips[g].lowsrc_s
						+ '" title="'
						+ this.filmstrips[g].title
						+ '" alt="'
						+ this.filmstrips[g].title
						+ '" oncontextmenu="event.returnValue=false;return false;" /></a></td><td class="pb_05"></td></tr><tr><td class="pb_06"></td><td class="pb_07"></td><td class="pb_08"></td></tr></table></td></tr>'
						+ '<tr><td>'
						+ (this.filmstrips[g].title.length > 20 ? this.filmstrips[g].title
								.substring(0, 20)
								+ "..."
								: this.filmstrips[g].title)
						+ '</td></tr></table></div>';
			} else {
				d += '<div class="pic" id="slide_'
						+ g
						+ '"><table cellspacing="0" width="98%"><tr><td class="picCont"><table cellspacing="0"><tr><td class="pb_01"></td><td class="pb_02"></td><td class="pb_03"></td></tr><tr><td class="pb_04"></td><td><a href="javascript:epidiascope.select('
						+ g
						+ ');" onclick="this.blur();"><img style="width: 80px;height: 80px;" src="'
						+ this.filmstrips[g].lowsrc_s
						+ '" title="'
						+ this.filmstrips[g].title
						+ '" alt="'
						+ this.filmstrips[g].title
						+ '" oncontextmenu="event.returnValue=false;return false;" /></a></td><td class="pb_05"></td></tr><tr><td class="pb_06"></td><td class="pb_07"></td><td class="pb_08"></td></tr></table></td></tr>'
						+ '<tr><td></td></tr></table></div>';
			}
		}
		picShow.ps(this.picListId).innerHTML = d + "</div>";
		picShow.ps(this.picArrLeftId).onclick = function() {
			epidiascope.previous();
			epidiascope.stop()
		};
		picShow.ps(this.picArrRightId).onclick = function() {
			epidiascope.next();
			epidiascope.stop()
		};
		if (window.location.href.indexOf("2010.") != -1) {
			this.autoPlay = true;
			picShow.ps(this.picArrRightId).onclick = function() {
				epidiascope.next();
				epidiascope.play()
			}
		}
		this.buttonNext = new epidiascope.Button("ecbNext");
		this.buttonPre = new epidiascope.Button("ecbPre");
		this.buttonPlay = new epidiascope.Button("ecbPlay");
		this.buttonMode = new epidiascope.Button("ecbMode");
		this.buttonSpeed = new epidiascope.Button("ecbSpeed");
		this.buttonModeReturn = new epidiascope.Button("ecbModeReturn");
		this.buttonPre.element.onclick = function() {
			epidiascope.previous();
			epidiascope.stop()
		};
		this.buttonNext.element.onclick = function() {
			epidiascope.next();
			epidiascope.stop()
		};
		this.buttonMode.element.onclick = function() {
			epidiascope.setMode("list")
		};
		this.buttonModeReturn.element.onclick = function() {
			epidiascope.setMode("player")
		};
		this.BigImgBox = picShow.ps(this.BigPicId);
		this.BigImgBox.oncontextmenu = function(i) {
			i = i ? i : event;
			i.returnValue = false;
			return false
		};
		this._imgLoad = function() {
			if (epidiascope.maxWidth == 0) {
				return

				

								

				

												

				

								

				

																

				

								

				

												

				

								

				

			}
			if (this.width > epidiascope.maxWidth) {
				this.width = epidiascope.maxWidth
			}
			if (this.width < 948) {
				picShow.ps("d_BigPic").style.paddingTop = "15px";
				this.style.border = "1px solid #000"
			} else {
				picShow.ps("d_BigPic").style.paddingTop = "0px";
				this.style.border = "none";
				this.style.borderBottom = "1px solid #e5e6e6"
			}
			clearTimeout(e._hideBgTimeObj);
			picShow.ps("d_BigPic").className = ""
		};
		this._preLoad = function() {
			var k = new Date().getTime();
			var i = k - epidiascope.loadTime;
			if (i > 5000) {
				var j = new Image().src = "http://roll.book.picShow.com.cn/interface/slow_log.php?time="
						+ i + "&url=" + encodeURIComponent(this.src) + "&t=1"
			}
		};
		this.createImg(this.filmstrips[0].src);
		var h;
		var c = window.location.search.match(/img=(\d+)/i);
		if (c) {
			c = c[1];
			h = 0;
			for ( var g = 0, a = this.filmstrips.length; g < a; g++) {
				if (parseInt(this.filmstrips[g]["id"]) == parseInt(c)) {
					h = g;
					break
				}
			}
		} else {
			h = window.location.hash.match(/p=(\d+)/i);
			if (h) {
				h = h[1] - 1;
				if (h < 0 || h >= this.filmstrips.length) {
					h = 0
				}
			} else {
				h = 0
			}
		}
		if (slide_data.slide.showCenter)
			this.select(h);
		if (!picShow.isIE) {
			this.BigImgBox.style.position = "relative";
			this.BigImgBox.style.overflow = "hidden"
		} else {
			clearInterval(this._ieButHeiTimeObj);
			this._ieButHeiTimeObj = setInterval(function() {
				e.setPicButtonHeight()
			}, 300)
		}
		var b = picShow.ps("efpNextGroup").getElementsByTagName("a");
		picShow.ps("nextPicsBut").href = b[0].href;
		picShow.ps("nextPicsBut").title = b[0].title;
		if (this.autoPlay) {
			this.play()
		} else {
			this.stop()
		}
		if (this.onstart) {
			this.onstart()
		}
	},
	initNot : function() {
		var e = this;
		var f = 0;
		if (this.filmstrips.length * 110 < picShow.ps(this.picListId).offsetWidth) {
			f = Math.round(picShow.ps(this.picListId).offsetWidth / 2
					- this.filmstrips.length * 110 / 2)
		}
		var d = '<div style="width:32760px;padding-left:' + f + 'px;">', g;
		for (g = 0; g < this.filmstrips.length; g++) {
			d += '<div class="pic" id="slide_'
					+ g
					+ '"><table cellspacing="0"><tr><td class="picCont"><table cellspacing="0"><tr><td class="pb_01"></td><td class="pb_02"></td><td class="pb_03"></td></tr><tr><td class="pb_04"></td><td><a href="javascript:epidiascope.select('
					+ g
					+ ');" onclick="this.blur();"><img src="'
					+ this.filmstrips[g].lowsrc_s
					+ '" alt="'
					+ this.filmstrips[g].title
					+ '"  onload="DrawImage(this);" oncontextmenu="event.returnValue=false;return false;" /></a></td><td class="pb_05"></td></tr><tr><td class="pb_06"></td><td class="pb_07"></td><td class="pb_08"></td></tr></table></td></tr></table></div>'
		}
		picShow.ps(this.picListId).innerHTML = d + "</div>";
		this.createImg(this.filmstrips[0].src);
		var h;
		var c = window.location.search.match(/img=(\d+)/i);
		if (c) {
			c = c[1];
			h = 0;
			for ( var g = 0, a = this.filmstrips.length; g < a; g++) {
				if (parseInt(this.filmstrips[g]["id"]) == parseInt(c)) {
					h = g;
					break
				}
			}
		} else {
			h = window.location.hash.match(/p=(\d+)/i);
			if (h) {
				h = h[1] - 1;
				if (h < 0 || h >= this.filmstrips.length) {
					h = 0
				}
			} else {
				h = 0
			}
		}
		this.select(h);
		setTimeout(function() {
			e.picList.foucsTo(h + 1)
		}, 500);
		if (!picShow.isIE) {
			this.BigImgBox.style.position = "relative";
			this.BigImgBox.style.overflow = "hidden"
		} else {
			clearInterval(this._ieButHeiTimeObj);
			this._ieButHeiTimeObj = setInterval(function() {
				e.setPicButtonHeight()
			}, 300)
		}
		this.listInitStatus = false;
		var b = picShow.ps("efpNextGroup").getElementsByTagName("a");
		picShow.ps("nextPicsBut").href = b[0].href;
		if (this.autoPlay) {
			this.play()
		} else {
			this.stop()
		}
		if (this.onstart) {
			this.onstart()
		}
	},
	readTry : 0,
	createImg : function(a) {
		if (this.ImgObj1) {
			this.BigImgBox.removeChild(this.ImgObj1)
		}
		this.ImgObj1 = document.createElement("img");
		this.ImgObj1.onmousedown = function() {
			return false
		};
		this.ImgObj1.galleryImg = false;
		this.ImgObj1.onload = this._imgLoad;
		if (a) {
			this.ImgObj1.src = a;
		}
		this.BigImgBox.appendChild(this.ImgObj1);
	},
	select : function(b, d) {
		var a = this;
		if (this.endSelect.status == 1) {
			this.endSelect.close()
		}
		if (b == this.selectedIndex) {
			return

			

						

			

									

			

						

			

												

			

						

			

									

			

						

			

															

			

						

			

									

			

						

			

												

			

						

			

									

			

						

			

		}
		var c;
		if (b >= this.filmstrips.length || b < 0) {
			return

			

						

			

									

			

						

			

												

			

						

			

									

			

						

			

		}
		picShow.ps(this.picTitleId).innerHTML = this.filmstrips[b].title;
		picShow.ps(this.picMemoId).innerHTML = this.filmstrips[b].text;
		picShow.ps("d_BigPic").className = "";
		clearTimeout(this._hideBgTimeObj);
		this._hideBgTimeObj = setTimeout(
				"picShow.ps('d_BigPic').className='loading'", 500);
		this.createImg();
		if (this._timeOut) {
			for (c = 0; c < this._timeOut.length; c++) {
				clearTimeout(this._timeOut[c])
			}
		}
		this._timeOut = [];
		if (picShow.isIE) {
			this.ImgObj1.src = "http://i0.sinaimg.cn/dy/deco/2008/0331/yocc080331img/news_mj_005.gif";
			this.ImgObj1.filters[0].Apply();
			this.ImgObj1.src = this.filmstrips[b].src;
			this.ImgObj1.filters[0].Play()
		} else {
			this.ImgObj1.style.opacity = 0;
			this.ImgObj1.src = this.filmstrips[b].src;
			for (c = 0; c <= 3; c++) {
				this._timeOut[c] = setTimeout(
						"epidiascope.ImgObj1.style.opacity = " + c * 0.3,
						c * 100)
			}
			this._timeOut[c] = setTimeout(
					"epidiascope.ImgObj1.style.opacity = 1;", 4 * 100)
		}
		if (picShow.ps("slide_" + this.selectedIndex)) {
			picShow.ps("slide_" + this.selectedIndex).className = "pic"
		}
		picShow.ps("slide_" + b).className = "picOn";
		this.selectedIndex = b;
		this.picList.foucsTo(b + 1);
		picShow.ps("total").innerHTML = '(<span class="cC00">' + (b + 1)
				+ "</span>/" + this.filmstrips.length + ")";
		if (this.autoPlay) {
			this.play()
		}
		if (!this.prefetch && b < this.filmstrips.length - 1) {
			this.reLoad = new Image();
			this.reLoad.src = this.filmstrips[b + 1].src;
			this.loadTime = new Date().getTime();
			this.reLoad.onload = this._preLoad
		}
	},
	setPicButtonHeight : function() {
		picShow.ps(this.picArrLeftId).style.height = picShow
				.ps(this.picArrRightId).style.height = picShow
				.ps(this.picArrLeftId).parentNode.offsetHeight
				+ "px"
	},
	setPageInfo : function(a) {
		window.location.hash = "p=" + Math.round(a + 1)
	},
	next : function(a) {
		var b = this.selectedIndex + 1;
		if (b >= this.filmstrips.length) {
			if (this.repetition) {
				b = 0
			} else {
				this.endSelect.open();
				return

				

								

				

												

				

								

				

																

				

								

				

												

				

								

				

			}
		}
		if (a == "auto") {
			var c = new Image();
			c.src = this.filmstrips[b].src;
			if (!c.complete) {
				return

				

								

				

												

				

								

				

																

				

								

				

												

				

								

				

																				

				

								

				

												

				

								

				

																

				

								

				

												

				

								

				

			}
		}
		this.select(b, a)
	},
	previous : function() {
		var a = this.selectedIndex - 1;
		if (a < 0) {
			if (this.repetition) {
				a = this.filmstrips.length - 1
			} else {
				return

				

								

				

												

				

								

				

																

				

								

				

												

				

								

				

			}
		}
		this.select(a)
	},
	play : function() {
		clearInterval(this.autoPlayTimeObj);
		this.autoPlayTimeObj = setInterval("epidiascope.next('auto')",
				this.timeSpeed * 1000);
		picShow.ps(this.playButtonId).onclick = function() {
			epidiascope.stop()
		};
		picShow.ps(this.statusId).className = "stop";
		picShow.ps(this.statusId).title = "��ͣ";
		this.autoPlay = true
	},
	stop : function() {
		clearInterval(this.autoPlayTimeObj);
		picShow.ps(this.playButtonId).onclick = function() {
			epidiascope.play();
			epidiascope.next("auto")
		};
		picShow.ps(this.statusId).className = "play";
		picShow.ps(this.statusId).title = "����";
		this.autoPlay = false
	},
	rePlay : function() {
		if (this.endSelect.status == 1) {
			this.endSelect.close()
		}
		this.autoPlay = true;
		this.select(0)
	},
	downloadPic : function() {
		var a = this.filmstrips[this.selectedIndex]
	},
	setMode : function(a) {
		this.speedBar.close();
		if (this.endSelect.status == 1) {
			this.endSelect.close()
		}
		if (a == "list") {
			if (!this.listInitStatus) {
				this.listInit()
			}
			this.buttonSpeed.hide();
			this.buttonPlay.hide();
			this.buttonNext.hide();
			this.buttonPre.hide();
			picShow.ps("ecbLine").style.visibility = "hidden";
			this.buttonMode.element.style.display = "none";
			this.buttonModeReturn.element.style.display = "block";
			this.buttonModeReturn.rePosi();
			this.stop();
			this.mode = "list";
			this.listSelect(this.selectedIndex);
			picShow.ps("eFramePic").style.display = "none";
			picShow.ps("ePicList").style.display = "block";
			this.listView()
		} else {
			window.scroll(0, 0);
			this.buttonSpeed.show();
			this.buttonPlay.show();
			this.buttonNext.show();
			this.buttonPre.show();
			picShow.ps("ecbLine").style.visibility = "visible";
			this.buttonMode.element.className = "";
			this.buttonMode.element.style.display = "block";
			this.buttonModeReturn.element.style.display = "none";
			this.mode = "player";
			picShow.ps("eFramePic").style.display = "block";
			picShow.ps("ePicList").style.display = "none"
		}
	},
	switchMode : function() {
		if (this.mode == "list") {
			this.setMode("player")
		} else {
			this.setMode("list")
		}
	},
	listData : null,
	listFrameId : "ePicList",
	listSelectedIndex : null,
	listSelect : function(a) {
		if (a < 0 || a >= this.filmstrips.length) {
			return

			

						

			

									

			

						

			

												

			

						

			

									

			

						

			

		}
		if (this.listSelectedIndex !== null) {
			if (picShow.ps("picList_" + this.listSelectedIndex)) {
				picShow.ps("picList_" + this.listSelectedIndex).className = "picBox"
			}
		}
		this.listSelectedIndex = a;
		if (picShow.ps("picList_" + this.listSelectedIndex)) {
			picShow.ps("picList_" + this.listSelectedIndex).className = "picBox selected"
		}
	},
	listInit : function() {
		var a = this;
		var c = "";
		for ( var b = 0; b < this.filmstrips.length; b++) {
			c += '<div class="picBox" id="picList_'
					+ b
					+ '" onmousemove="epidiascope.listSelect('
					+ b
					+ ')" onclick="epidiascope.select(epidiascope.listSelectedIndex);epidiascope.setMode(\'player\');"><table cellspacing="0"><tr><td><img style="width: 160px;height: 160px;" src="'
					+ this.filmstrips[b].lowsrc_b
					+ '" alt="" /></td></tr></table><h3>'
					+ this.filmstrips[b].title + '</h3><p class="time">'
					+ this.filmstrips[b].date + "</p></div>"
		}
		picShow.ps(this.listFrameId).innerHTML = c;
		this.listInitStatus = true
	},
	listRowSize : 4,
	listView : function() {
		var b = picShow.ps("picList_" + this.listSelectedIndex);
		var d = document.documentElement.clientHeight == 0 ? document.body.clientHeight
				: document.documentElement.clientHeight;
		var c = document.documentElement.scrollTop == 0 ? document.body.scrollTop
				: document.documentElement.scrollTop;
		var a = picShow.absPosition(b, document.documentElement);
		if ((a.top + (b.offsetHeight * 0.3)) < c
				|| (a.top + (b.offsetHeight * 0.7)) > c + d) {
			window.scroll(0, a.top - Math.round((d - b.offsetHeight) / 2))
		}
	},
	listMoveUp : function() {
		var a = this.listSelectedIndex - this.listRowSize;
		if (a < 0) {
			return

			

						

			

									

			

						

			

												

			

						

			

									

			

						

			

		}
		this.listSelect(a);
		this.listView()
	},
	listMoveDown : function() {
		var a = this.listSelectedIndex + this.listRowSize;
		if (a >= this.filmstrips.length) {
			nweNum = this.filmstrips.length - 1
		}
		this.listSelect(a);
		this.listView()
	},
	listMoveLeft : function() {
		var a = this.listSelectedIndex - 1;
		if (a < 0) {
			return

			

						

			

									

			

						

			

												

			

						

			

									

			

						

			

		}
		this.listSelect(a);
		this.listView()
	},
	listMoveRight : function() {
		var a = this.listSelectedIndex + 1;
		if (a >= this.filmstrips.length) {
			return

			

						

			

									

			

						

			

												

			

						

			

									

			

						

			

															

			

						

			

									

			

						

			

												

			

						

			

									

			

						

			

		}
		this.listSelect(a);
		this.listView()
	}
};
epidiascope.speedBar = {
	boxId : "SpeedBox",
	contId : "SpeedCont",
	slideId : "SpeedSlide",
	slideButtonId : "SpeedNonius",
	infoId : "ecbSpeedInfo",
	grades : 10,
	grade : 5,
	_slideHeight : 112,
	_slideButtonHeight : 9,
	_baseTop : 4,
	_marginTop : 0,
	_mouseDisparity : 0,
	_showStep : 0,
	_showType : "close",
	_showTimeObj : null,
	init : function() {
		var a = this;
		this._marginTop = Math.round(this._slideHeight / this.grades
				* (this.grade - 1));
		picShow.ps(this.slideButtonId).style.top = this._marginTop
				+ this._baseTop + "px";
		picShow.ps(this.infoId).innerHTML = this.grade + "��";
		this.step = new picShow.Step();
		this.step.element = picShow.ps(this.contId);
		this.step.limit = 6;
		this.step.stepTime = 20;
		this.step.classBase = "speedStep_";
		this.step.onfirst = function() {
			epidiascope.buttonSpeed.setStatus("ok");
			picShow.ps(epidiascope.speedBar.boxId).style.display = "none"
		};
		picShow.ps(this.slideId).onselectstart = function() {
			return false
		};
		picShow.ps(this.slideButtonId).onmousedown = function(b) {
			a.mouseDown(b);
			return false
		};
		picShow.ps(this.slideId).onmousedown = function(b) {
			a.slideClick(b);
			return false
		};
		epidiascope.buttonSpeed.element.onmousedown = function() {
			a.show();
			return false
		};
		epidiascope.buttonSpeed.element.onselectstart = function() {
			return false
		}
	},
	show : function() {
		if (this._showType == "close") {
			this.open()
		} else {
			this.close()
		}
	},
	open : function() {
		var a = this;
		this._showType = "open";
		var c = document.onmousedown;
		var b = function(f) {
			f = window.event ? event : f;
			if (f.stopPropagation) {
				f.stopPropagation()
			} else {
				window.event.cancelBubble = true
			}
			var d = f.target ? f.target : f.srcElement;
			while (d != picShow.ps(a.boxId)
					&& d != epidiascope.buttonSpeed.element) {
				if (d.parentNode) {
					d = d.parentNode
				} else {
					break
				}
			}
			if (d == picShow.ps(a.boxId)
					|| d == epidiascope.buttonSpeed.element) {
				return

				

								

				

												

				

								

				

																

				

								

				

												

				

								

				

																				

				

								

				

												

				

								

				

																

				

								

				

												

				

								

				

			} else {
				a.close()
			}
			picShow.delEvent(document, "mousedown", b)
		};
		picShow.addEvent(document, "mousedown", b);
		epidiascope.buttonSpeed.setStatus("down");
		picShow.ps(this.boxId).style.display = "block";
		this.step.action("+")
	},
	close : function() {
		var a = this;
		this._showType = "close";
		epidiascope.buttonSpeed.setStatus("ok");
		this.step.action("-")
	},
	slideClick : function(a) {
		a = window.event ? event : a;
		var b = a.layerY ? a.layerY : a.offsetY;
		if (!b) {
			return

			

						

			

									

			

						

			

												

			

						

			

									

			

						

			

															

			

						

			

									

			

						

			

												

			

						

			

									

			

						

			

		}
		this._marginTop = b - Math.round(this._slideButtonHeight / 2);
		if (this._marginTop < 0) {
			this._marginTop = 0
		}
		this.grade = Math.round(this._marginTop
				/ (this._slideHeight / this.grades) + 1);
		picShow.ps(this.slideButtonId).style.top = this._marginTop
				+ this._baseTop + "px";
		picShow.ps(this.infoId).innerHTML = this.grade + "��";
		if (this.onend) {
			this.onend()
		}
	},
	setGrade : function(a) {
		this.grade = a;
		epidiascope.timeSpeed = this.grade;
		this._marginTop = Math.round(this._slideHeight / this.grades
				* (this.grade - 1));
		picShow.ps(this.slideButtonId).style.top = this._marginTop
				+ this._baseTop + "px";
		picShow.ps(this.infoId).innerHTML = this.grade + "��";
		picShow.writeCookie("eSp", this.grade, 720)
	},
	mouseDown : function(b) {
		var a = this;
		b = window.event ? window.event : b;
		this._mouseDisparity = (b.pageY ? b.pageY : b.clientY)
				- this._marginTop;
		document.onmousemove = function(c) {
			a.mouseOver(c)
		};
		document.onmouseup = function() {
			a.mouseEnd()
		}
	},
	mouseOver : function(a) {
		a = window.event ? window.event : a;
		this._marginTop = (a.pageY ? a.pageY : a.clientY)
				- this._mouseDisparity;
		if (this._marginTop > (this._slideHeight - this._slideButtonHeight)) {
			this._marginTop = this._slideHeight - this._slideButtonHeight
		}
		if (this._marginTop < 0) {
			this._marginTop = 0
		}
		picShow.ps(this.slideButtonId).style.top = this._marginTop
				+ this._baseTop + "px";
		this.grade = Math.round(this._marginTop
				/ (this._slideHeight / this.grades) + 1);
		if (this.onmover) {
			this.onmover()
		}
	},
	mouseEnd : function() {
		if (this.onend) {
			this.onend()
		}
		document.onmousemove = null;
		document.onmouseup = null
	},
	onmover : function() {
		picShow.ps(this.infoId).innerHTML = this.grade + "��"
	},
	onend : function() {
		picShow.writeCookie("eSp", this.grade, 720);
		epidiascope.timeSpeed = this.grade;
		if (epidiascope.autoPlay) {
			epidiascope.play()
		}
	}
};
epidiascope.picList = {
	leftArrId : "efpListLeftArr",
	rightArrId : "efpListRightArr",
	picListId : "efpPicListCont",
	timeoutObj : null,
	pageWidth : 110,
	totalWidth : 0,
	offsetWidth : 0,
	lock : false,
	init : function() {
		picShow.ps(this.rightArrId).onmousedown = function() {
			epidiascope.picList.leftMouseDown()
		};
		picShow.ps(this.rightArrId).onmouseout = function() {
			epidiascope.picList.leftEnd("out");
			this.className = ""
		};
		picShow.ps(this.rightArrId).onmouseup = function() {
			epidiascope.picList.leftEnd("up")
		};
		picShow.ps(this.leftArrId).onmousedown = function() {
			epidiascope.picList.rightMouseDown()
		};
		picShow.ps(this.leftArrId).onmouseout = function() {
			epidiascope.picList.rightEnd("out");
			this.className = ""
		};
		picShow.ps(this.leftArrId).onmouseup = function() {
			epidiascope.picList.rightEnd("up")
		};
		this.totalWidth = epidiascope.filmstrips.length * this.pageWidth;
		this.offsetWidth = picShow.ps(this.picListId).offsetWidth
	},
	leftMouseDown : function() {
		if (this.lock) {
			return

			

						

			

									

			

						

			

												

			

						

			

									

			

						

			

		}
		this.lock = true;
		this.timeoutObj = setInterval("epidiascope.picList.moveLeft()", 10)
	},
	rightMouseDown : function() {
		if (this.lock) {
			return

			

						

			

									

			

						

			

												

			

						

			

									

			

						

			

															

			

						

			

									

			

						

			

												

			

						

			

									

			

						

			

		}
		this.lock = true;
		this.timeoutObj = setInterval("epidiascope.picList.moveRight()", 10)
	},
	moveLeft : function() {
		if (picShow.ps(this.picListId).scrollLeft + 10 > this.totalWidth
				- this.offsetWidth) {
			picShow.ps(this.picListId).scrollLeft = this.totalWidth
					- this.offsetWidth;
			this.leftEnd()
		} else {
			picShow.ps(this.picListId).scrollLeft += 10
		}
	},
	moveRight : function() {
		picShow.ps(this.picListId).scrollLeft -= 10;
		if (picShow.ps(this.picListId).scrollLeft == 0) {
			this.rightEnd()
		}
	},
	leftEnd : function(a) {
		if (a == "out") {
			if (!this.lock) {
				return

				

								

				

												

				

								

				

																

				

								

				

												

				

								

				

																				

				

								

				

												

				

								

				

																

				

								

				

												

				

								

				

			}
		}
		clearInterval(this.timeoutObj);
		this.lock = false;
		this.move(30)
	},
	rightEnd : function(a) {
		if (a == "out") {
			if (!this.lock) {
				return

				

								

				

												

				

								

				

																

				

								

				

												

				

								

				

			}
		}
		clearInterval(this.timeoutObj);
		this.lock = false;
		this.move(-30)
	},
	foucsTo : function(a) {
		if (this.lock) {
			return

			

						

			

									

			

						

			

												

			

						

			

									

			

						

			

															

			

						

			

									

			

						

			

												

			

						

			

									

			

						

			

		}
		this.lock = true;
		var b = Math.round(a * this.pageWidth - this.offsetWidth / 2) - 33;
		b -= picShow.ps(this.picListId).scrollLeft;
		if (picShow.ps(this.picListId).scrollLeft + b < 0) {
			b = -picShow.ps(this.picListId).scrollLeft
		}
		if (picShow.ps(this.picListId).scrollLeft + b >= this.totalWidth
				- this.offsetWidth) {
			b = this.totalWidth - this.offsetWidth
					- picShow.ps(this.picListId).scrollLeft
		}
		this.move(b)
	},
	move : function(b) {
		var c = b / 4;
		if (Math.abs(c) < 1 && c != 0) {
			c = (c >= 0 ? 1 : -1) * 1
		} else {
			c = Math.round(c)
		}
		var a = picShow.ps(this.picListId).scrollLeft + c;
		if (a <= 0) {
			picShow.ps(this.picListId).scrollLeft = 0;
			this.lock = false;
			return

			

						

			

									

			

						

			

												

			

						

			

									

			

						

			

		}
		if (a >= this.totalWidth - this.offsetWidth) {
			picShow.ps(this.picListId).scrollLeft = this.totalWidth
					- this.offsetWidth;
			this.lock = false;
			return

			

						

			

									

			

						

			

												

			

						

			

									

			

						

			

		}
		picShow.ps(this.picListId).scrollLeft += c;
		b -= c;
		if (Math.abs(b) <= 1) {
			this.lock = false;
			return

			

						

			

									

			

						

			

												

			

						

			

									

			

						

			

		} else {
			setTimeout("epidiascope.picList.move(" + b + ")", 10)
		}
	}
};
epidiascope.keyboard = {
	_timeObj : null,
	status : "up",
	init : function() {
		var a = this;
		picShow.addEvent(document, "keydown", function(b) {
			a.keyDown(b)
		});
		picShow.addEvent(document, "keyup", function(b) {
			a.keyUp(b)
		});
		this.step = new picShow.Step();
		this.step.element = picShow.ps("efpClew");
		this.step.limit = 5;
		this.step.stepTime = 30;
		this.step.classBase = "efpClewStep_";
		if (!this.closeObj) {
			this.closeObj = document.createElement("span");
			this.closeObj.style.display = "block";
			this.closeObj.id = "efpClewClose";
			picShow.ps("efpClew").appendChild(this.closeObj);
			this.closeObj.onclick = function() {
				a.clewClose()
			}
		}
		this.clewNum = parseInt(picShow.readCookie("eCn"));
		if (isNaN(this.clewNum)) {
			this.clewNum = 0
		}
		if (this.clewNum < 5) {
			this.clewOpen()
		}
	},
	clewClose : function() {
		this.step.action("-");
		picShow.writeCookie("eCn", 6, 24 * 7)
	},
	clewOpen : function() {
		this.step.action("+")
	},
	keyDown : function(c) {
		if (this.status == "down") {
			return

			

						

			

									

			

						

			

												

			

						

			

									

			

						

			

		}
		this.status = "down";
		c = window.event ? event : c;
		var b = c.target ? c.target : c.srcElement;
		if (b.tagName == "INPUT" || b.tagName == "SELECT"
				|| b.tagName == "TEXTAREA") {
			if (c.stopPropagation) {
				c.stopPropagation()
			} else {
				window.event.cancelBubble = true
			}
			return

			

						

			

									

			

						

			

												

			

						

			

									

			

						

			

		}
		var a = false;
		if (epidiascope.mode == "list") {
			if (c.keyCode == 40) {
				epidiascope.listMoveDown();
				a = true
			}
			if (c.keyCode == 37) {
				epidiascope.listMoveLeft();
				a = true
			}
			if (c.keyCode == 38) {
				epidiascope.listMoveUp();
				a = true
			}
			if (c.keyCode == 39) {
				epidiascope.listMoveRight();
				a = true
			}
			if (c.keyCode == 13) {
				epidiascope.setMode("player");
				epidiascope.select(epidiascope.listSelectedIndex);
				a = true
			}
		} else {
			if (c.keyCode == 39) {
				epidiascope.next();
				a = true;
				this.clewClose()
			}
			if (c.keyCode == 37) {
				epidiascope.previous();
				a = true;
				this.clewClose()
			}
		}
		if (c.keyCode == 9) {
			epidiascope.switchMode();
			a = true
		}
		if (a === true) {
			if (c.preventDefault) {
				c.preventDefault()
			} else {
				c.returnValue = false
			}
		}
	},
	keyUp : function() {
		this.status = "up"
	}
};
epidiascope.endSelect = {
	endSelectId : "endSelect",
	closeId : "endSelClose",
	rePlayButId : "rePlayBut",
	status : 0,
	open : function() {
		this.status = 1;
		picShow.ps(this.endSelectId).style.display = "block";
		picShow.ps(this.endSelectId).style.left = Math.round((picShow
				.ps(epidiascope.mainBoxId).offsetWidth - picShow
				.ps(this.endSelectId).offsetWidth) / 2)
				+ "px";
		picShow.ps(this.endSelectId).style.top = Math.round((picShow
				.ps(epidiascope.mainBoxId).offsetHeight - picShow
				.ps(this.endSelectId).offsetHeight) / 2)
				+ "px";
		epidiascope.stop();
		picShow.ps(epidiascope.playButtonId).onclick = function() {
			epidiascope.rePlay()
		};
		picShow.ps(this.closeId).onclick = function() {
			epidiascope.endSelect.close()
		};
		picShow.ps(this.rePlayButId).onclick = function() {
			epidiascope.rePlay()
		}
	},
	close : function() {
		this.status = 0;
		picShow.ps(this.endSelectId).style.display = "none"
	}
};
epidiascope.onstart = function() {
	try {
		document.execCommand("BackgroundImageCache", false, true)
	} catch (a) {
	}
	epidiascope.speedBar.grade = parseInt(picShow.readCookie("eSp"));
	if (isNaN(epidiascope.speedBar.grade)) {
		epidiascope.speedBar.grade = 5
	}
	epidiascope.speedBar.init();
	epidiascope.speedBar.onend();
	epidiascope.picList.init();
	epidiascope.keyboard.init()
};
epidiascope.Button = function(b, a) {
	this.status = "ok";
	this.id = b;
	this.classNameNum = a;
	this.init()
};
epidiascope.Button.prototype.init = function() {
	if (!picShow.ps(this.id)) {
		return

		

				

		

						

		

				

		

								

		

				

		

						

		

				

		

	}
	var a = this;
	this.element = picShow.ps(this.id);
	if (this.element.offsetWidth == 43) {
		this.classNameNum = "1"
	}
	if (!this.classNameNum) {
		this.classNameNum = ""
	}
	this.mouseStatus = "out";
	this.bgDiv = document.createElement("div");
	this.bgDiv.className = "buttonBg" + this.classNameNum;
	this.element.parentNode.style.position = "relative";
	this.element.style.position = "relative";
	this.element.style.zIndex = "5";
	this.element.parentNode.appendChild(this.bgDiv);
	this.bgDiv.style.top = this.element.offsetTop - 6 + "px";
	this.bgDiv.style.left = this.element.offsetLeft - 6 + "px";
	this.step = new picShow.Step();
	this.step.element = this.bgDiv;
	this.step.limit = 3;
	this.step.stepTime = 30;
	this.step.classBase = "buttonBg" + this.classNameNum + " bBg"
			+ this.classNameNum + "S_";
	picShow.addEvent(this.element, "mouseover", function() {
		a.mouseover()
	});
	picShow.addEvent(this.element, "mouseout", function() {
		a.mouseout()
	});
	picShow.addEvent(this.element, "mousedown", function() {
		a.mousedown()
	});
	picShow.addEvent(this.element, "mouseup", function() {
		a.mouseup()
	})
};
epidiascope.Button.prototype.rePosi = function() {
	this.bgDiv.style.top = this.element.offsetTop - 6 + "px";
	this.bgDiv.style.left = this.element.offsetLeft - 6 + "px"
};
epidiascope.Button.prototype.mouseover = function() {
	this.mouseStatus = "in";
	if (this.status != "down") {
		this.element.className = "hover";
		this.step.action("+")
	}
};
epidiascope.Button.prototype.mouseout = function() {
	this.mouseStatus = "out";
	if (this.status != "down") {
		this.element.className = "";
		this.step.action("-")
	}
};
epidiascope.Button.prototype.mouseup = function() {
	if (this.status == "down") {
		return

		

				

		

						

		

				

		

								

		

				

		

						

		

				

		

	}
	this.element.className = "hover"
};
epidiascope.Button.prototype.mousedown = function() {
	if (this.status == "down") {
		return

		

				

		

						

		

				

		

								

		

				

		

						

		

				

		

										

		

				

		

						

		

				

		

								

		

				

		

						

		

				

		

	}
	this.element.className = "active"
};
epidiascope.Button.prototype.setStatus = function(a) {
	switch (a) {
	case "ok":
		this.status = "ok";
		this.element.className = "";
		if (this.mouseStatus == "in") {
			this.step.action("+")
		} else {
			this.step.action("-")
		}
		break;
	case "down":
		this.status = "down";
		this.step.action("-");
		this.element.className = "active";
		break
	}
};
epidiascope.Button.prototype.hide = function() {
	this.element.style.visibility = "hidden";
	this.bgDiv.style.visibility = "hidden"
};
epidiascope.Button.prototype.show = function() {
	this.element.style.visibility = "visible";
	this.bgDiv.style.visibility = "visible"
};
function DrawImage(e, b, d) {
	var c = new Image();
	if (!b) {
		b = 90
	}
	if (!d) {
		d = 90
	}
	c.src = e.src;
	if (c.width > 0 && c.height > 0) {
		var a = true;
		if (c.width / c.height >= b / d) {
			if (c.width > b) {
				e.width = b;
				e.height = (c.height * b) / c.width
			} else {
				e.width = c.width;
				e.height = c.height
			}
		} else {
			if (c.height > d) {
				e.height = d;
				e.width = (c.width * d) / c.height
			} else {
				e.width = c.width;
				e.height = c.height
			}
		}
	}
}
function DivSelect(e, a, b) {
	var g = this;
	g.id = e;
	g.divId = a;
	g.divClassName = b;
	g.selectObj = picShow.ps(g.id);
	if (!g.selectObj) {
		return

		

				

		

						

		

				

		

								

		

				

		

						

		

				

		

	}
	var f = g;
	g.status = "close";
	g.parentObj = g.selectObj.parentNode;
	while (picShow.readStyle(g.parentObj, "display") != "block") {
		if (g.parentObj.parentNode) {
			g.parentObj = g.parentObj.parentNode
		} else {
			break
		}
	}
	g.parentObj.style.position = "relative";
	g.selectObjWidth = g.selectObj.offsetWidth;
	g.selectObjHeight = g.selectObj.offsetHeight;
	g.selectPosition = picShow.absPosition(g.selectObj, g.parentObj);
	g.selectObj.style.visibility = "hidden";
	g.divObj = document.createElement("div");
	g.divObj.id = g.divId;
	if (g.divClassName) {
		g.divObj.className = g.divClassName
	}
	g.parentObj.appendChild(g.divObj);
	g.divObj.style.width = g.selectObjWidth + "px";
	g.divObj.style.position = "absolute";
	g.divObj.style.left = g.selectPosition.left + "px";
	g.divObj.style.top = g.selectPosition.top + "px";
	g.divObj.onclick = function() {
		f.click()
	};
	g.divObj_count = document.createElement("div");
	g.divObj.appendChild(g.divObj_count);
	g.divObj_count.className = "ds_cont";
	g.divObj_title = document.createElement("div");
	g.divObj_count.appendChild(g.divObj_title);
	g.divObj_title.className = "ds_title";
	g.divObj_button = document.createElement("div");
	g.divObj_count.appendChild(g.divObj_button);
	g.divObj_button.className = "ds_button";
	g.divObj_list = document.createElement("div");
	g.divObj.appendChild(g.divObj_list);
	g.divObj_list.className = "ds_list";
	g.divObj_list.style.display = "none";
	g.divObj_listCont = document.createElement("div");
	g.divObj_list.appendChild(g.divObj_listCont);
	g.divObj_listCont.className = "dsl_cont";
	g.list = [];
	var d;
	for ( var h = 0; h < g.selectObj.options.length; h++) {
		d = document.createElement("p");
		g.list.push(d);
		g.divObj_listCont.appendChild(d);
		d.innerHTML = g.selectObj.options[h].innerHTML;
		if (g.selectObj.selectedIndex == h) {
			g.divObj_title.innerHTML = d.innerHTML
		}
		d.onmouseover = function() {
			this.className = "selected"
		};
		d.onmouseout = function() {
			this.className = ""
		};
		d.onclick = function() {
			f.select(this.innerHTML)
		}
	}
	g.select = function(k) {
		var c = this;
		for ( var j = 0; j < c.selectObj.options.length; j++) {
			if (c.selectObj.options[j].innerHTML == k) {
				c.selectObj.selectedIndex = j;
				if (c.selectObj.onchange) {
					c.selectObj.onchange()
				}
				c.divObj_title.innerHTML = k;
				break
			}
		}
	};
	g.clickClose = function(c) {
		var j = c.target ? c.target : event.srcElement;
		do {
			if (j == f.divObj) {
				return

				

								

				

												

				

								

				

																

				

								

				

												

				

								

				

			}
			if (j.tagName == "BODY") {
				break
			}
			j = j.parentNode
		} while (j.parentNode);
		f.close()
	};
	g.open = function() {
		var c = this;
		c.divObj_list.style.display = "block";
		c.status = "open";
		picShow.addEvent(document, "click", c.clickClose)
	};
	g.close = function() {
		var c = this;
		c.divObj_list.style.display = "none";
		c.status = "close";
		picShow.delEvent(document, "click", c.clickClose)
	};
	g.click = function() {
		var c = this;
		if (c.status == "open") {
			c.close()
		} else {
			c.open()
		}
	}
}
function _initData() {
	getData.curUrl = "";
	getData.fillData();
	window.scrollTo(0, 40)
}
function _checkShowOther() {
	var b = $("efpNextGroup");
	b.style.display = "none";
	var a = $("efpPreGroup");
	a.style.display = "none";
	var c = $("efpPicListCont");
	c.style.width = ($("wrap").getWidth() - 90) + "px";
};