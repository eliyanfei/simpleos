//v.3.5 build 120731

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
You allowed to use this component or parts of it under GPL terms
To use it on other terms or get Professional edition of the component please contact us at sales@dhtmlx.com
*/
dhtmlXLayoutObject.prototype.tplData["4G"]='<layout><autosize hor="d" ver="c;d" rows="3" cols="2"/><table data="a,d;b,d;c,d"/><row><cell obj="a" wh="2,3" resize="ver" neighbors="a;b;c"/><cell sep="ver" left="a,b,c" right="d" dblclick="d" rowspan="5"/><cell obj="d" wh="2,1" resize="hor" neighbors="a,b,c;d" rowspan="5"/></row><row sep="true"><cell sep="hor" top="a" dblclick="a" bottom="b;c"/></row><row><cell obj="b" wh="2,3" resize="ver" neighbors="a;b;c"/></row><row sep="true"><cell sep="hor" top="a;b" dblclick="b" bottom="c"/></row><row><cell obj="c" wh="2,3" resize="ver" neighbors="a;b;c"/></row></layout>';
dhtmlXLayoutObject.prototype._availAutoSize["4G_hor"]=["a;b;c","d"];dhtmlXLayoutObject.prototype._availAutoSize["4G_ver"]=["a;d","b;d","c;d"];

//v.3.5 build 120731

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
You allowed to use this component or parts of it under GPL terms
To use it on other terms or get Professional edition of the component please contact us at sales@dhtmlx.com
*/