//v.3.5 build 120731

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
You allowed to use this component or parts of it under GPL terms
To use it on other terms or get Professional edition of the component please contact us at sales@dhtmlx.com
*/
dhtmlXLayoutObject.prototype.tplData["4E"]='<layout><autosize hor="a;b;c;d" ver="d" rows="4" cols="1"/><table data="a;b;c;d"/><row><cell obj="a" wh="1,4" resize="ver" neighbors="a;b;c;d"/></row><row sep="yes"><cell sep="hor" top="a" bottom="b;c;d" dblclick="a"/></row><row><cell obj="b" wh="1,4" resize="ver" neighbors="a;b;c;d"/></row><row sep="yes"><cell sep="hor" top="a;b" bottom="c;d" dblclick="b"/></row><row><cell obj="c" wh="1,4" resize="ver" neighbors="a;b;c;d"/></row><row sep="yes"><cell sep="hor" top="a;b;c" bottom="d" dblclick="c"/></row><row><cell obj="d" wh="1,4" resize="ver" neighbors="a;b;c;d"/></row></layout>';
dhtmlXLayoutObject.prototype._availAutoSize["4E_hor"]=["a;b;c;d"];dhtmlXLayoutObject.prototype._availAutoSize["4E_ver"]=["a","b","c","d"];

//v.3.5 build 120731

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
You allowed to use this component or parts of it under GPL terms
To use it on other terms or get Professional edition of the component please contact us at sales@dhtmlx.com
*/