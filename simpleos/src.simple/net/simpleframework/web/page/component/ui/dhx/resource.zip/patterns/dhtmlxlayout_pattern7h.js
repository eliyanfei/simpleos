//v.3.5 build 120731

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
You allowed to use this component or parts of it under GPL terms
To use it on other terms or get Professional edition of the component please contact us at sales@dhtmlx.com
*/
dhtmlXLayoutObject.prototype.tplData["7H"]='<layout><autosize hor="g" ver="a;f;g" rows="5" cols="3"/><table data="a,b,g;a,c,g;a,d,g;a,e,g;a,f,g"/><row><cell obj="a" wh="3,1" resize="hor" neighbors="a;b,c,d,e,f" rowspan="9"/><cell sep="ver" left="a" right="b,c,d,e,f;g" dblclick="a" rowspan="9"/><cell obj="b" wh="3,5" resize="ver" neighbors="b;c;d;e;f"/><cell sep="ver" left="a;b,c,d,e,f" right="g" dblclick="g" rowspan="9"/><cell obj="g" wh="3,1" resize="hor" neighbors="b,c,d,e,f;g" rowspan="9"/></row><row sep="true"><cell sep="hor" top="b" dblclick="b" bottom="c;d;e;f"/></row><row><cell obj="c" wh="3,5" resize="ver" neighbors="b;c;d;e;f"/></row><row sep="true"><cell sep="hor" top="b;c" dblclick="c" bottom="d;e;f"/></row><row><cell obj="d" wh="3,5" resize="ver" neighbors="b;c;d;e;f"/></row><row sep="true"><cell sep="hor" top="b;c;d" dblclick="d" bottom="e;f"/></row><row><cell obj="e" wh="3,5" resize="ver" neighbors="b;c;d;e;f"/></row><row sep="true"><cell sep="hor" top="b;c;d;e" dblclick="e" bottom="f"/></row><row><cell obj="f" wh="3,5" resize="ver" neighbors="b;c;d;e;f"/></row></layout>';
dhtmlXLayoutObject.prototype._availAutoSize["7H_hor"]=["a","b;c;d;e;f","g"];dhtmlXLayoutObject.prototype._availAutoSize["7H_ver"]=["a;b;g","a;c;g","a;d;g","a;e;g","a;f;g"];

//v.3.5 build 120731

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
You allowed to use this component or parts of it under GPL terms
To use it on other terms or get Professional edition of the component please contact us at sales@dhtmlx.com
*/