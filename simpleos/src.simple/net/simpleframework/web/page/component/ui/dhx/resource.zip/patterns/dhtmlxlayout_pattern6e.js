//v.3.5 build 120731

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
You allowed to use this component or parts of it under GPL terms
To use it on other terms or get Professional edition of the component please contact us at sales@dhtmlx.com
*/
dhtmlXLayoutObject.prototype.tplData["6E"]='<layout><autosize hor="c;d;e;f" ver="a;b;f" rows="4" cols="3"/><table data="a,b,c;a,b,d;a,b,e;a,b,f"/><row><cell obj="a" wh="3,1" resize="hor" neighbors="a;b;c,d,e,f" rowspan="7"/><cell sep="ver" left="a" right="b;c,d,e,f" dblclick="a" rowspan="7"/><cell obj="b" wh="3,1" resize="hor" neighbors="a;b;c,d,e,f" rowspan="7"/><cell sep="ver" left="a;b" right="c,d,e,f" dblclick="b" rowspan="7"/><cell obj="c" wh="3,4" resize="ver" neighbors="c;d;e;f"/></row><row sep="yes"><cell sep="hor" top="c" bottom="d;e;f" dblclick="c"/></row><row><cell obj="d" wh="3,4" resize="ver" neighbors="c;d;e;f"/></row><row sep="yes"><cell sep="hor" top="c;d" bottom="e;f" dblclick="d"/></row><row><cell obj="e" wh="3,4" resize="ver" neighbors="c;d;e;f"/></row><row sep="yes"><cell sep="hor" top="c;d;e" bottom="f" dblclick="e"/></row><row><cell obj="f" wh="3,4" resize="ver" neighbors="c;d;e;f"/></row></layout>';
dhtmlXLayoutObject.prototype._availAutoSize["6E_hor"]=["a","b","c;d;e;f"];dhtmlXLayoutObject.prototype._availAutoSize["6E_ver"]=["a;b;c","a;b;d","a;b;e","a,b,f"];

//v.3.5 build 120731

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
You allowed to use this component or parts of it under GPL terms
To use it on other terms or get Professional edition of the component please contact us at sales@dhtmlx.com
*/