//v.3.5 build 120731

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
You allowed to use this component or parts of it under GPL terms
To use it on other terms or get Professional edition of the component please contact us at sales@dhtmlx.com
*/
dhtmlXLayoutObject.prototype.tplData["6C"]='<layout><autosize hor="b;c;d;e;f" ver="a;f" rows="5" cols="2"/><table data="a,b;a,c;a,d;a,e;a,f"/><row><cell obj="a" wh="2,1" resize="hor" neighbors="a;b,c,d,e,f" rowspan="9"/><cell sep="ver" left="a" right="b,c,d,e,f" dblclick="a" rowspan="9"/><cell obj="b" wh="2,5" resize="ver" neighbors="b;c;d;e;f"/></row><row sep="yes"><cell sep="hor" top="b" bottom="c;d;e;f" dblclick="b"/></row><row><cell obj="c" wh="2,5" resize="ver" neighbors="b;c;d;e;f"/></row><row sep="yes"><cell sep="hor" top="b;c" bottom="d;e;f" dblclick="c"/></row><row><cell obj="d" wh="2,5" resize="ver" neighbors="b;c;d;e;f"/></row><row sep="yes"><cell sep="hor" top="b;c;d" bottom="e;f" dblclick="c"/></row><row><cell obj="e" wh="2,5" resize="ver" neighbors="b;c;d;e;f"/></row><row sep="yes"><cell sep="hor" top="b;c;d;e" bottom="f" dblclick="c"/></row><row><cell obj="f" wh="2,5" resize="ver" neighbors="b;c;d;e;f"/></row></layout>';
dhtmlXLayoutObject.prototype._availAutoSize["6C_hor"]=["a","b;c;d;e;f"];dhtmlXLayoutObject.prototype._availAutoSize["6C_ver"]=["a;b","a;c","a;d","a;e","a;f"];

//v.3.5 build 120731

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
You allowed to use this component or parts of it under GPL terms
To use it on other terms or get Professional edition of the component please contact us at sales@dhtmlx.com
*/