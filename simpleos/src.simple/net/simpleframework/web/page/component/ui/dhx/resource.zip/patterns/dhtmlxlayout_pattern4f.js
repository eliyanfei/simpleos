//v.3.5 build 120731

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
You allowed to use this component or parts of it under GPL terms
To use it on other terms or get Professional edition of the component please contact us at sales@dhtmlx.com
*/
dhtmlXLayoutObject.prototype.tplData["4F"]='<layout><autosize hor="b;c;d" ver="d" rows="3" cols="2"/><table data="a,b;c,c;d,d"/><row><cell obj="a" wh="2,3" resize="hor" neighbors="a;b"/><cell sep="ver" left="a" right="b" dblclick="a"/><cell obj="b" wh="2,3" resize="hor" neighbors="a;b"/></row><row sep="true"><cell sep="hor" top="a,b" bottom="c;d" dblclick="c" colspan="3"/></row><row><cell obj="c" wh="1,3" resize="ver" neighbors="a,b;c;d" colspan="3"/></row><row sep="true"><cell sep="hor" top="a,b;c" bottom="d" dblclick="d" colspan="3"/></row><row><cell obj="d" wh="1,3" resize="ver" neighbors="a,b;c;d" colspan="3"/></row></layout>';
dhtmlXLayoutObject.prototype._availAutoSize["4F_hor"]=["a;c;d","b;c;d"];dhtmlXLayoutObject.prototype._availAutoSize["4F_ver"]=["a;b","c","d"];

//v.3.5 build 120731

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
You allowed to use this component or parts of it under GPL terms
To use it on other terms or get Professional edition of the component please contact us at sales@dhtmlx.com
*/