//v.3.5 build 120731

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
You allowed to use this component or parts of it under GPL terms
To use it on other terms or get Professional edition of the component please contact us at sales@dhtmlx.com
*/
dhtmlXLayoutObject.prototype.tplData["5W"]='<layout><autosize hor="e" ver="a;b;c;d;e" rows="1" cols="5"/><table data="a,b,c,d,e"/><row><cell obj="a" wh="5,1" resize="hor" neighbors="a;b;c;d;e"/><cell sep="ver" left="a" right="b;c;d;e" dblclick="a"/><cell obj="b" wh="5,1" resize="hor" neighbors="a;b;c;d;e"/><cell sep="ver" left="a;b" right="c;d;e" dblclick="b"/><cell obj="c" wh="5,1" resize="hor" neighbors="a;b;c;d;e"/><cell sep="ver" left="a;b;c" right="d;e" dblclick="c"/><cell obj="d" wh="5,1" resize="hor" neighbors="a;b;c;d;e"/><cell sep="ver" left="a;b;c;d" right="e" dblclick="d"/><cell obj="e" wh="5,1" resize="hor" neighbors="a;b;c;d;e"/></row></layout>';
dhtmlXLayoutObject.prototype._availAutoSize["5W_hor"]=["a","b","c","d","e"];dhtmlXLayoutObject.prototype._availAutoSize["5W_ver"]=["a;b;c;d;e"];

//v.3.5 build 120731

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
You allowed to use this component or parts of it under GPL terms
To use it on other terms or get Professional edition of the component please contact us at sales@dhtmlx.com
*/