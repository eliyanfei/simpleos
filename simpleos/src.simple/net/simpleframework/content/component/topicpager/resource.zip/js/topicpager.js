
function __topicpager_addMethods(action, idParameterName) {
	var _params = function(o, params) {
		return (idParameterName + "=" + action.rowId(o)).addParameter(params);
	};
	
	action.add = function(params) {
		var win = $Actions["topicPagerWindow"];
		win.contentRef = $Actions["ajaxTopicPagerAdd"];
		win.contentRef.selector = action.selector;
		win(params);
	};

	action.edit = function(o, params) {
		var win = $Actions["topicPagerWindow"];
		win.contentRef = $Actions["ajaxTopicPagerEdit"];
		win.contentRef.selector = action.selector;
		win(_params(o, params));
	};
	
	action.update = function(o, params) {
		var am = $Actions["ajaxTopicUpdate"];
		am.selector = action.selector;
		am(_params(o, params));
	};
	
	action.edit2 = function(o, params) {
		$Actions["ajaxTopicEdit2"].selector = action.selector;
		$Actions["topicEdit2Window"](_params(o, params));
	};

	action.del = function(o, params) {
		var da = $Actions["topicPagerDelete"];
		da.selector = action.selector;
		da(_params(o, params));
	};

	action.del2 = function(params) {
		action.__checkall(function(ids) {
			var da = $Actions["topicPagerDelete"];
			da.selector = action.selector;
			da((idParameterName + "=" + ids).addParameter(params));
		});
	};

	action.view = function(o, params) {
		var av = $Actions["ajaxTopicPagerView"];
		av.container = action.pager.up();
		av.selector = action.selector;
		av(params);
	};
	
	action.move2 = function(o, params) {
		var ma = $Actions["topicMove2Dict"];
		ma.selector = action.selector;
		ma.move2_callback = function(selects) {
			var id = selects[0].id;
			var ta = $Actions["ajaxTopicMove2"];
			ta.selector = action.selector;
			ta(("mCatalog=" + id).addParameter(_params(o, params)));
			return true;
		};
		ma(params);
	};
}