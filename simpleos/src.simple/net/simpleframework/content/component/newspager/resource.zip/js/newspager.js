
function __newspager_addMethods(action, idParameterName) {
	var _params = function(o, params) {
		return (idParameterName + "=" + action.rowId(o)).addParameter(params);
	};
	
	action.add = function(params) {
		$Actions["ajaxAddNewspagerPage"].selector = action.selector;
		$Actions["addNewspagerWindow"](params);
	};
	
	action.edit = function(o, params) {
		$Actions["ajaxAddNewspagerPage"].selector = action.selector;
		$Actions["addNewspagerWindow"](_params(o, params));
	};
	
	action.edit2 = function(o, params) {
		var sa = $Actions["ajaxNewsEdit2"];
		sa.selector = action.selector;
		$Actions["newsEditWindow2"](_params(o, params));
	};
	
	action.del = function(o, params) {
		var da = $Actions["newspagerDelete"];
		da.selector = action.selector;
		da(_params(o, params));
	};

	action.del2 = function(params) {
		action.__checkall(function(ids) {
			var da = $Actions["newspagerDelete"];
			da.selector = action.selector;
			da((idParameterName + "=" + ids).addParameter(params));
		});
	};
}